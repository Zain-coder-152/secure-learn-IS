'use strict';

const express = require('express');
const router = express.Router();

const db = require('../db');
const config = require('../config');
const { verifyCsrfToken } = require('../security');

// ---- Course list -----------------------------------------------------------
router.get('/', (req, res) => {
  const courses = db.prepare('SELECT * FROM courses ORDER BY code').all();
  res.render('courses', { courses });
});

// ---- Course detail ---------------------------------------------------------
// SQL INJECTION -- LEVEL 3 (HARD): blind, boolean-based, on a numeric field.
//
// VULNERABLE: the :id segment is concatenated into the query with no quotes.
// Because it is numeric there is nothing to "escape", which is exactly why
// people forget to parameterise it. An attacker uses the page's found/not-found
// response as a true/false oracle, e.g.
//   /courses/3 and 1=1            -> course shown  (TRUE)
//   /courses/3 and 1=2            -> not found     (FALSE)
// and then extracts data one bit at a time, e.g.
//   /courses/3 and substr((select password from users where username='admin'),1,1)='S'
//
// SAFE: validate that the id is actually an integer, then bind it as a
// parameter. Non-numeric input is rejected outright.
router.get('/:id', (req, res) => {
  let course;

  if (config.isSafe) {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || String(id) !== req.params.id) {
      return res.status(404).render('error', { message: 'Course not found.' });
    }
    course = db.prepare('SELECT * FROM courses WHERE id = ?').get(id);
  } else {
    const sql = `SELECT * FROM courses WHERE id = ${req.params.id}`;
    console.log('[vuln][course] SQL:', sql);
    try {
      course = db.prepare(sql).get();
    } catch (err) {
      return res.status(400).render('error', { message: 'SQL error: ' + err.message });
    }
  }

  if (!course) {
    return res.status(404).render('error', { message: 'Course not found.' });
  }

  const comments = db
    .prepare('SELECT * FROM comments WHERE course_id = ? ORDER BY id DESC')
    .all(course.id);

  res.render('course', { course, comments });
});

// ---- Post a comment --------------------------------------------------------
// STORED (PERSISTENT) XSS lives here.
//
// The raw comment body is saved to the database verbatim in BOTH modes -- that
// is realistic; storage is not where the bug is. The difference is at OUTPUT:
//   - VULNERABLE: the view prints the body unescaped (<%- %>), so a stored
//     <script> or <img onerror=...> runs for every visitor who opens the page.
//   - SAFE: the view HTML-escapes the body (<%= %>), so it is shown as text.
// The CSRF token is also enforced here in safe mode.
router.post('/:id/comments', (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) {
    return res.status(400).render('error', { message: 'Invalid course id.' });
  }

  if (config.isSafe && !verifyCsrfToken(req.session, req.body._csrf)) {
    return res.status(403).render('error', { message: 'Invalid CSRF token.' });
  }

  const author = (req.session.user && req.session.user.username) || 'guest';
  const body = req.body.body || '';

  db.prepare('INSERT INTO comments (course_id, author, body) VALUES (?, ?, ?)').run(
    id,
    author,
    body
  );

  res.redirect('/courses/' + id);
});

module.exports = router;
