# SecureLearn — Web Security Blue-Team Lab

A single full-stack education-portal web app that exists in **two builds from one
codebase**, selected by the `MODE` environment variable:

| MODE | What it is |
|------|------------|
| `vulnerable` | Deliberately insecure. Every attack below genuinely works. |
| `safe` | The hardened build. Every attack below is genuinely blocked. |

It demonstrates, with **working exploits and working fixes**, the vulnerability
classes required by the assignment:

- **XSS** — reflected, stored, and DOM-based
- **CSRF** — forged state-changing request (account email change → takeover)
- **SQL injection** — three levels: easy (auth bypass), medium (UNION dump),
  hard (blind boolean on a numeric field)

> ⚠️ **The `vulnerable` build is intentionally exploitable. Run it only on
> `localhost` in an isolated lab. Never deploy it or expose it to a network.**

---

## Tech stack

- **Node.js + Express** — web server and routing
- **EJS** — server-side templates (its `<%= %>` auto-escaping is part of the XSS fix)
- **better-sqlite3** — a real SQL database, so the SQL injection is genuine (not simulated)
- **express-session** — cookie sessions (the CSRF target)

No build step, no external services. One command to run.

---

## Setup & run

```bash
# 1. install dependencies
npm install

# 2. create and seed the database (safe to re-run; resets to a clean state)
npm run initdb

# 3a. run the VULNERABLE build
npm run vuln       # http://localhost:3000

# 3b. or run the SAFE build
npm run safe       # http://localhost:3000
```

Only one build runs at a time (both default to port 3000). Stop one before
starting the other, or give one a different port:

```bash
MODE=safe PORT=3100 node src/server.js
```

### Demo accounts

| Username | Password | Role |
|----------|----------|------|
| `alice` | `password123` | student |
| `bob` | `qwerty` | student |
| `admin` | `SuperSecretAdminPass!` | admin |

> **Why plaintext passwords?** So the SQL-injection UNION attack can visibly leak
> credentials out of the `users` table — that is the lesson being demonstrated.
> A production app would store a salted hash (bcrypt/argon2). This is the one
> intentional simplification and it is unrelated to the fixes being taught.

---

## How the two builds share one codebase

`src/config.js` reads `MODE` and exposes `isSafe`. Every route branches on it, so
the **same URL** behaves two different ways depending on how the server was
started. Nothing is stubbed or commented out — both code paths are fully wired
and both are real. Open any route file and you can read the insecure version and
its fix side by side.

```
src/
  config.js            MODE flag (vulnerable | safe)
  server.js            app setup, sessions, security headers, CSRF token wiring
  security.js          escapeHtml() + CSRF synchroniser-token helpers (safe mode)
  db/
    index.js           SQLite connection
    seed.js            schema + demo data  (npm run initdb)
  routes/
    auth.js            login/logout  -> SQLi Level 1 (login bypass)
    courses.js         course pages + comments -> STORED XSS, SQLi Level 3 (blind)
    search.js          search page   -> REFLECTED XSS, DOM XSS, SQLi Level 2 (UNION)
    profile.js         profile + change email -> CSRF
  views/               EJS templates (escaping decisions live here)
public/
  js/dom-vuln.js       DOM XSS: innerHTML sink (vulnerable)
  js/dom-safe.js       DOM XSS: textContent sink (safe)
  css/style.css
attacker/
  csrf.html            cross-site CSRF proof-of-concept page
docs/
  PAYLOADS.md          every payload, step by step, with the fix for each
```

---

## The vulnerabilities and their fixes (summary)

Full step-by-step payloads and reproduction steps are in **[docs/PAYLOADS.md](docs/PAYLOADS.md)**.

### Cross-Site Scripting (XSS)

| Type | Where | The bug | The fix |
|------|-------|---------|---------|
| **Reflected** | `/search?q=` | `q` echoed into the page unescaped | HTML-escape on output (EJS `<%= %>`) + CSP |
| **Stored** | course comments | comment body rendered as raw HTML (`<%- %>`) | HTML-escape on output (`<%= %>`) + CSP |
| **DOM-based** | `/search#...` | client JS writes `location.hash` into `innerHTML` | write to `textContent` (safe sink) + CSP |

Key idea: XSS is an **output-encoding** bug. Data is fine until it is placed into
an HTML context without encoding. The fix is to encode at the point of output and
to add a Content-Security-Policy as defence-in-depth.

### Cross-Site Request Forgery (CSRF)

- **Where:** `POST /profile/email` (changing your account email → account takeover).
- **The bug:** no anti-CSRF token, and the session cookie is `SameSite=None`, so a
  page the victim merely visits can auto-submit a form that rides the victim's
  session. See `attacker/csrf.html`.
- **The fix:** a per-session **synchroniser token** that the attacker cannot read,
  verified with a constant-time compare on every state-changing POST, plus a
  `SameSite=Lax` cookie as a second layer.

### SQL Injection

| Level | Where | Technique | The fix |
|-------|-------|-----------|---------|
| **1 — Easy** | login | `' OR 1=1 --` authentication bypass | prepared statement with bound params |
| **2 — Medium** | search | `UNION SELECT` to dump credentials in-band | bound parameter for the `LIKE` pattern |
| **3 — Hard** | `/courses/:id` | blind boolean on a numeric field | integer validation + bound param |

Key idea: SQL injection is fixed by **never building queries with string
concatenation**. Prepared statements send the query structure and the data
separately, so input can never change the query's meaning.

---

## How to demonstrate both sides quickly

1. Run `npm run vuln`. Walk through each payload in `docs/PAYLOADS.md` and watch it
   succeed (login bypass, credential dump, alert boxes, silent email change).
2. Stop the server, run `npm run initdb` to reset, then `npm run safe`.
3. Repeat the **exact same** payloads and watch each one fail (invalid login,
   empty results, payloads shown as text, `403 Invalid CSRF token`).

An automated check that runs every payload against both builds is described at the
end of `docs/PAYLOADS.md`.
