'use strict';

/*
 * Creates the schema and seeds demo data.
 * Run with:  npm run initdb   (or  node src/db/seed.js )
 *
 * This is safe to run repeatedly: it drops and recreates the tables each time
 * so every demo starts from a known, clean state.
 *
 * NOTE ON PASSWORDS: passwords are stored in plaintext here ON PURPOSE, because
 * the SQL-injection login-bypass demo needs to show credentials leaking out of
 * the users table via a UNION attack. In a production app you would store a
 * salted hash (bcrypt/argon2). This is called out in the README so nobody
 * mistakes it for the lesson being taught.
 */

const db = require('./index');

function seed() {
  db.exec(`
    DROP TABLE IF EXISTS comments;
    DROP TABLE IF EXISTS enrollments;
    DROP TABLE IF EXISTS courses;
    DROP TABLE IF EXISTS users;

    CREATE TABLE users (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      username  TEXT UNIQUE NOT NULL,
      password  TEXT NOT NULL,
      email     TEXT NOT NULL,
      role      TEXT NOT NULL DEFAULT 'student'
    );

    CREATE TABLE courses (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      code         TEXT NOT NULL,
      title        TEXT NOT NULL,
      description  TEXT NOT NULL,
      instructor   TEXT NOT NULL
    );

    CREATE TABLE comments (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id  INTEGER NOT NULL,
      author     TEXT NOT NULL,
      body       TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (course_id) REFERENCES courses(id)
    );
  `);

  const insertUser = db.prepare(
    'INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)'
  );
  insertUser.run('alice', 'password123', 'alice@securelearn.edu', 'student');
  insertUser.run('bob', 'qwerty', 'bob@securelearn.edu', 'student');
  insertUser.run('admin', 'SuperSecretAdminPass!', 'admin@securelearn.edu', 'admin');

  const insertCourse = db.prepare(
    'INSERT INTO courses (code, title, description, instructor) VALUES (?, ?, ?, ?)'
  );
  const courses = [
    ['CS101', 'Introduction to Programming', 'Variables, loops, functions and problem solving in Python.', 'Dr. Khan'],
    ['CS201', 'Data Structures', 'Arrays, linked lists, trees, graphs and complexity analysis.', 'Dr. Ahmed'],
    ['CS330', 'Web Security', 'Common web vulnerabilities and how to defend against them.', 'Dr. Fatima'],
    ['MT100', 'Calculus I', 'Limits, derivatives and integrals with applications.', 'Dr. Raza'],
  ];
  const courseIds = courses.map((c) => insertCourse.run(...c).lastInsertRowid);

  const insertComment = db.prepare(
    'INSERT INTO comments (course_id, author, body) VALUES (?, ?, ?)'
  );
  insertComment.run(courseIds[0], 'alice', 'Great intro course, the examples really helped!');
  insertComment.run(courseIds[0], 'bob', 'The pace was perfect for a beginner like me.');
  insertComment.run(courseIds[2], 'alice', 'Looking forward to the XSS lecture.');

  console.log('Database seeded at', db.DB_PATH);
  console.log('Demo accounts:');
  console.log('  alice / password123   (student)');
  console.log('  bob   / qwerty        (student)');
  console.log('  admin / SuperSecretAdminPass!  (admin)');
}

seed();
