// DOM-BASED XSS -- SAFE version.
//
// Same untrusted source (location.hash), but written to a safe sink. Using
// textContent means the browser treats the value as plain text and never parses
// it as HTML, so the same payload shows up harmlessly as literal characters:
//
//   http://localhost:3000/search#<img src=x onerror=alert(document.cookie)>
//
// displays the text "<img src=x onerror=alert(document.cookie)>" and nothing
// executes. (The Content-Security-Policy set in safe mode is a second layer:
// even an injected inline script would be refused by the browser.)
(function () {
  var box = document.getElementById('hashbox');
  if (!box) return;

  function render() {
    var fragment = decodeURIComponent(location.hash.slice(1));
    if (fragment) {
      box.textContent = fragment; // <-- safe sink
    }
  }

  window.addEventListener('hashchange', render);
  render();
})();
