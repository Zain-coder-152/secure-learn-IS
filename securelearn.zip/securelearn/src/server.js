'use strict';

const path = require('path');
const express = require('express');
const session = require('express-session');

const config = require('./config');
const { generateCsrfToken } = require('./security');

const authRoutes = require('./routes/auth');
const courseRoutes = require('./routes/courses');
const searchRoutes = require('./routes/search');
const profileRoutes = require('./routes/profile');

const app = express();

// ---- View engine ----------------------------------------------------------
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ---- Body parsing ----------------------------------------------------------
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// ---- Static assets ---------------------------------------------------------
app.use('/static', express.static(path.join(__dirname, '..', 'public')));

// ---- Sessions --------------------------------------------------------------
app.use(
  session({
    secret: config.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      // SAFE mode sets SameSite=Lax, which alone blocks most cross-site POST
      // CSRF. VULNERABLE mode uses SameSite=None so the CSRF demo works and we
      // can show the token defence doing the real work on top.
      sameSite: config.isSafe ? 'lax' : 'none',
    },
  })
);

// ---- Security headers (SAFE mode only) ------------------------------------
// A Content-Security-Policy is defence-in-depth for XSS: even if some markup
// slipped through, the browser refuses to run inline/injected scripts.
app.use((req, res, next) => {
  if (config.isSafe) {
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    );
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
  }
  next();
});

// ---- Expose common data to every view -------------------------------------
app.use((req, res, next) => {
  res.locals.MODE = config.MODE;
  res.locals.isSafe = config.isSafe;
  res.locals.user = req.session.user || null;
  // In SAFE mode, make a CSRF token available to every rendered form.
  res.locals.csrfToken = config.isSafe ? generateCsrfToken(req.session) : null;
  next();
});

// ---- Routes ----------------------------------------------------------------
app.get('/', (req, res) => res.redirect('/courses'));
app.use('/', authRoutes);
app.use('/courses', courseRoutes);
app.use('/search', searchRoutes);
app.use('/profile', profileRoutes);

// ---- 404 -------------------------------------------------------------------
app.use((req, res) => {
  res.status(404).render('error', { message: 'Page not found.' });
});

// ---- Start -----------------------------------------------------------------
app.listen(config.PORT, () => {
  const banner =
    config.MODE === 'safe'
      ? 'SAFE (hardened) build'
      : 'VULNERABLE build  -- for isolated lab use only';
  console.log('==================================================');
  console.log(`  SecureLearn  |  MODE = ${config.MODE}`);
  console.log(`  ${banner}`);
  console.log(`  http://localhost:${config.PORT}`);
  console.log('==================================================');
});
