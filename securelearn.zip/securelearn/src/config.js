'use strict';

/*
 * Central configuration.
 *
 * The whole point of this project is to show the SAME feature twice:
 *   - MODE=vulnerable  -> the insecure implementation (what NOT to do)
 *   - MODE=safe        -> the hardened implementation (the fix)
 *
 * Every route file reads `isSafe` and branches on it, so you can demo the
 * exact same URL behaving two different ways just by restarting the server
 * with a different MODE. Nothing is commented out or stubbed; both code
 * paths are real and fully wired.
 */

const MODE = (process.env.MODE || 'vulnerable').toLowerCase();

if (MODE !== 'vulnerable' && MODE !== 'safe') {
  console.error(`Invalid MODE="${MODE}". Use MODE=vulnerable or MODE=safe.`);
  process.exit(1);
}

module.exports = {
  MODE,
  isSafe: MODE === 'safe',
  isVulnerable: MODE === 'vulnerable',
  PORT: Number(process.env.PORT) || 3000,
  // Session secret is fixed here only so the lab is reproducible.
  // In a real app this would come from an environment secret.
  SESSION_SECRET: process.env.SESSION_SECRET || 'securelearn-lab-secret',
};
