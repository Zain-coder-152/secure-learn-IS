// DOM-BASED XSS -- VULNERABLE version.
//
// The "source" is location.hash (attacker-controlled, never leaves the browser,
// so the server never sees it). The "sink" is innerHTML, which parses the value
// as HTML. Putting an untrusted source into this sink lets markup execute:
//
//   http://localhost:3000/search#<img src=x onerror=alert(document.cookie)>
//
// The <img> fails to load, fires onerror, and the script runs -- entirely
// client-side, which is what makes DOM XSS different from reflected/stored.
(function () {
  var box = document.getElementById('hashbox');
  if (!box) return;

  function render() {
    var fragment = decodeURIComponent(location.hash.slice(1));
    if (fragment) {
      box.innerHTML = fragment; // <-- dangerous sink
    }
  }

  window.addEventListener('hashchange', render);
  render();
})();
