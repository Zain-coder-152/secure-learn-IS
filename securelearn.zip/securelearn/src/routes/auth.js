'use strict';

const express = require('express');
const router = express.Router();

const db = require('../db');
const config = require('../config');
const { verifyCsrfToken } = require('../security');

// ---- Login form ------------------------------------------------------------
router.get('/login', (req, res) => {
  res.render('login', { error: null, info: req.query.info || null });
});

// ---- Login submit ----------------------------------------------------------
// SQL INJECTION -- LEVEL 1 (EASY): authentication bypass.
//
// VULNERABLE: the username and password are concatenated straight into the SQL
// string. Input of  username = ' OR 1=1 --  turns the WHERE clause into
//   WHERE username = '' OR 1=1 --' AND password = '...'
// The  OR 1=1  matches every row and  --  comments out the password check, so
// the first user (alice) is logged in with no valid credentials.
//
// SAFE: a prepared statement with bound parameters. The input can never change
// the structure of the query; it is only ever treated as a literal value.
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (config.isSafe) {
    // CSRF token is also required on the login POST in safe mode.
    if (!verifyCsrfToken(req.session, req.body._csrf)) {
      return res.status(403).render('error', { message: 'Invalid CSRF token.' });
    }
    const row = db
      .prepare('SELECT * FROM users WHERE username = ? AND password = ?')
      .get(username, password);
    if (!row) {
      return res.render('login', { error: 'Invalid username or password.', info: null });
    }
    req.session.user = { id: row.id, username: row.username, email: row.email, role: row.role };
    return res.redirect('/courses');
  }

  // VULNERABLE path -----------------------------------------------------------
  const sql = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
  console.log('[vuln][login] SQL:', sql);
  let row;
  try {
    row = db.prepare(sql).get();
  } catch (err) {
    // Error-based injection also leaks here: the raw SQLite error is shown.
    return res.render('login', { error: 'SQL error: ' + err.message, info: null });
  }
  if (!row) {
    return res.render('login', { error: 'Invalid username or password.', info: null });
  }
  req.session.user = { id: row.id, username: row.username, email: row.email, role: row.role };
  return res.redirect('/courses');
});

// ---- Logout ----------------------------------------------------------------
router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login?info=You+have+been+logged+out.'));
});

module.exports = router;
