'use strict';

const crypto = require('crypto');

/*
 * Small security helpers used by the SAFE code paths.
 * Kept tiny and dependency-free so every line is explainable at the viva.
 */

/**
 * HTML-entity-encode a string so it can be placed into HTML text/attributes
 * without the browser interpreting it as markup. This is the core defence
 * against stored and reflected XSS: user input becomes inert text.
 */
function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * CSRF protection (synchroniser-token pattern).
 *
 * - generateCsrfToken(session): create a random token once per session and
 *   store it server-side in the session object.
 * - verifyCsrfToken(session, submitted): constant-time compare of the token
 *   the form sent back against the one we stored. A forged cross-site request
 *   cannot read the victim's token, so it cannot produce a matching value.
 */
function generateCsrfToken(session) {
  if (!session.csrfToken) {
    session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  return session.csrfToken;
}

function verifyCsrfToken(session, submitted) {
  const expected = session && session.csrfToken;
  if (!expected || !submitted) return false;
  const a = Buffer.from(String(expected));
  const b = Buffer.from(String(submitted));
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

module.exports = { escapeHtml, generateCsrfToken, verifyCsrfToken };
