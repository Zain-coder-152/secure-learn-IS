'use strict';

const path = require('path');
const Database = require('better-sqlite3');

// Single shared connection. The DB file lives next to this module.
const DB_PATH = path.join(__dirname, 'securelearn.db');
const db = new Database(DB_PATH);

// WAL mode: better concurrency, and it keeps the demo snappy.
db.pragma('journal_mode = WAL');

module.exports = db;
module.exports.DB_PATH = DB_PATH;
