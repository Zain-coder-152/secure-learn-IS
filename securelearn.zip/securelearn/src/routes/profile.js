'use strict';

const express = require('express');
const router = express.Router();

const db = require('../db');
const config = require('../config');
const { verifyCsrfToken } = require('../security');

// Must be logged in to view or change a profile.
function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login?info=Please+log+in+first.');
  }
  next();
}

// ---- View profile ----------------------------------------------------------
router.get('/', requireLogin, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.user.id);
  res.render('profile', { profile: user, updated: req.query.updated || null });
});

// ---- Change email ----------------------------------------------------------
// CSRF lives here. Changing a user's email is a classic CSRF target because it
// enables account takeover (attacker points the account at their own inbox,
// then does a password reset).
//
// VULNERABLE: the POST has no anti-CSRF token and the session cookie is sent on
// cross-site requests (SameSite=None), so a malicious page the victim merely
// visits can auto-submit a hidden form and silently change the victim's email.
// See attacker/csrf.html for the working proof-of-concept.
//
// SAFE: a per-session synchroniser token is required and verified, and the
// cookie is SameSite=Lax. A cross-site page cannot read the victim's token, so
// the forged request is rejected with 403.
router.post('/email', requireLogin, (req, res) => {
  if (config.isSafe && !verifyCsrfToken(req.session, req.body._csrf)) {
    return res.status(403).render('error', { message: 'Invalid CSRF token.' });
  }

  const newEmail = req.body.email || '';
  db.prepare('UPDATE users SET email = ? WHERE id = ?').run(newEmail, req.session.user.id);
  req.session.user.email = newEmail;

  res.redirect('/profile?updated=1');
});

module.exports = router;
