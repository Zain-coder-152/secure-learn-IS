'use strict';

const express = require('express');
const router = express.Router();

const db = require('../db');
const config = require('../config');

// ---- Search ----------------------------------------------------------------
// Two separate vulnerabilities share this one page:
//
// 1) REFLECTED XSS: the search term `q` is echoed back into the results page.
//    - VULNERABLE: the view prints it unescaped, so
//        /search?q=<script>alert(document.cookie)</script>
//      executes immediately in the victim's browser.
//    - SAFE: the view HTML-escapes it, so it is displayed as literal text.
//
// 2) SQL INJECTION -- LEVEL 2 (MEDIUM): in-band, UNION-based exfiltration.
//    - VULNERABLE: `q` is concatenated into a LIKE clause. The course results
//      table has 4 columns, so a matching UNION pulls rows out of `users`:
//        /search?q=' UNION SELECT username, password, email, role FROM users --
//      and the stolen credentials render in the results list.
//    - SAFE: a bound parameter is used for the LIKE pattern; the input can only
//      ever be a search string, never SQL.
router.get('/', (req, res) => {
  const q = req.query.q || '';
  let results = [];
  let sqlError = null;

  if (q.length > 0) {
    if (config.isSafe) {
      results = db
        .prepare(
          'SELECT code, title, description, instructor FROM courses WHERE title LIKE ? OR code LIKE ?'
        )
        .all(`%${q}%`, `%${q}%`);
    } else {
      const sql = `SELECT code, title, description, instructor FROM courses WHERE title LIKE '%${q}%'`;
      console.log('[vuln][search] SQL:', sql);
      try {
        results = db.prepare(sql).all();
      } catch (err) {
        sqlError = err.message;
      }
    }
  }

  res.render('search', { q, results, sqlError });
});

module.exports = router;
